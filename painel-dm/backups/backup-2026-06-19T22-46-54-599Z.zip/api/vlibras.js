/**
 * API VLibras Plugin
 * Gerenciamento de instalação/desinstalação do widget VLibras
 */

const express = require('express');
const router = express.Router();
const fs = require('fs');
const path = require('path');

const PLUGINS_FILE = path.join(__dirname, '../data/plugins.json');
const VLIBRAS_PLUGIN_ID = 'vlibras';

/**
 * GET /api/vlibras/status
 * Verificar status de instalação
 */
router.get('/status', (req, res) => {
  try {
    const plugins = JSON.parse(fs.readFileSync(PLUGINS_FILE, 'utf8'));
    const vlibras = plugins.find(p => p.id === VLIBRAS_PLUGIN_ID);

    res.json({
      instalado: vlibras?.instalado || false,
      plugin: vlibras || null
    });
  } catch (err) {
    res.status(500).json({ erro: err.message });
  }
});

/**
 * POST /api/vlibras/instalar
 * Instalar VLibras no portal
 */
router.post('/instalar', (req, res) => {
  try {
    let plugins = JSON.parse(fs.readFileSync(PLUGINS_FILE, 'utf8'));

    // Encontrar ou criar plugin VLibras
    let vlibras = plugins.find(p => p.id === VLIBRAS_PLUGIN_ID);

    if (!vlibras) {
      vlibras = {
        id: VLIBRAS_PLUGIN_ID,
        nome: 'VLibras',
        descricao: 'Tradutor automático para Libras (Língua Brasileira de Sinais)',
        categoria: 'acessibilidade',
        tipo: 'gratis',
        versao: '1.0.0',
        ultimaVersao: '1.0.0',
        icone: 'mao',
        cor: '#1877f2',
        config: {
          posicao: 'bottom-right',
          url: 'https://vlibras.gov.br/app'
        }
      };
      plugins.push(vlibras);
    }

    // Marcar como instalado
    vlibras.instalado = true;
    vlibras.instaladoEm = new Date().toISOString();

    // Salvar
    fs.writeFileSync(PLUGINS_FILE, JSON.stringify(plugins, null, 2));

    console.log('✓ [VLibras API] Plugin instalado');
    res.json({
      sucesso: true,
      mensagem: 'VLibras instalado com sucesso',
      plugin: vlibras
    });
  } catch (err) {
    console.error('❌ [VLibras API] Erro ao instalar:', err);
    res.status(500).json({ erro: err.message });
  }
});

/**
 * POST /api/vlibras/desinstalar
 * Desinstalar VLibras do portal
 */
router.post('/desinstalar', (req, res) => {
  try {
    let plugins = JSON.parse(fs.readFileSync(PLUGINS_FILE, 'utf8'));

    const vlibras = plugins.find(p => p.id === VLIBRAS_PLUGIN_ID);
    if (vlibras) {
      vlibras.instalado = false;
      delete vlibras.instaladoEm;
    }

    fs.writeFileSync(PLUGINS_FILE, JSON.stringify(plugins, null, 2));

    console.log('✓ [VLibras API] Plugin desinstalado');
    res.json({
      sucesso: true,
      mensagem: 'VLibras desinstalado com sucesso'
    });
  } catch (err) {
    console.error('❌ [VLibras API] Erro ao desinstalar:', err);
    res.status(500).json({ erro: err.message });
  }
});

module.exports = router;
